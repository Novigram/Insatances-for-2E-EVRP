In all the instances text files, the first column illustrates the type of each vertex, where "D" ,"S","C"and "F"denotes depot, 
satellites, customers and recharging stations, respectively.

The second and third columns show the x-coordinate and y-coordinante of each vertex.

The last column gives the demands of each vertex.

File "RSDA" gives  25 instances which are divided into 5 groups for recharging station density analysis.

In each group, there are 5 instances text files named by "instance x-y.txt" which denote the instance that derived from instance x with y recharging stations.